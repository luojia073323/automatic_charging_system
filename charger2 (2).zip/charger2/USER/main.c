#include "sys.h"
#include "delay.h"
//#include "usart.h"
#include "red.h" 
#include "beep.h"
#include "key.h"
#include "relay.h"
#include "oled.h"
//#include "oledfont.h"
#include "ds18b20.h"
#include "usart2.h"
#include "timer2.h"

u8 buf[100];
u8 temp0[20];
float Temp;
//uint8_t Uart_Getchar();
// u8 Res = 'a';
 extern u8 Res;
	
int main(void)
{ 
	u8 key;
//	u8 t;
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);															//����ϵͳ�ж����ȼ�����2
	delay_init();    
//	uart_init(115200); 	
	usart2_init(115200); 
	TIM2_Int_Init(9999,143);
	RED_Init();				 
	BEEP_Init();             
	RELAY_Init();
	OLED_Init();
	ds18b20_init_x();
//	OLED_Clear();
	
	printf2("init2 is seccess!!\r\n\r\n");

	while(1)
	{		
		Temp =  (ds18b20_read()& 0x07FF)/16.;
//		sprintf((char*)buf,"temperature:%2.2f*",Temp);
		sprintf((char*)temp0,"Temp:%2.2f*",Temp);
//		temper= (uint16_t)DS18B20_Get_Temp();
//		OLED_ShowCHinese(0,8,8);
//		OLED_ShowCHinese(18,8,8);
//		OLED_ShowChar(36,8,':',16);
		OLED_ShowString(8,8,temp0,32);
//		OLED_ShowNum(54,8,Temp,2,16);
//		OLED_ShowCHinese(76,8,10);
		delay_ms(500);	
		OLED_Refresh_Gram(); 
		
		key = KEY_Scan(0);
		if(key)
		{
			switch(key)
			{
				case KEY1_PRES:
				RELAY=!RELAY;
				break;
			}		  
		}
		else delay_ms(10);	

		if(Res == 'A') GPIO_ResetBits(GPIOB,GPIO_Pin_6);	
		if(Res == 'a') GPIO_SetBits(GPIOB,GPIO_Pin_6);
//		printf("relay\n");
		
	}	
}

//	uint8_t Uart_Getchar()
//	{
//		uint8_t ch;
//		while(!(USART2->SR &(1<<5)));
//		ch = USART2->DR;
//		return ch;
//	}
	
