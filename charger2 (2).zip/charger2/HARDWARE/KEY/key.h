#ifndef __KEY_H
#define __KEY_H	 
#include "sys.h" 

/*����ķ�ʽ��ͨ��ֱ�Ӳ����⺯����ʽ��ȡIO*/
#define KEY1 		GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_0) 																		//PB0
#define KEY2 		GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_1)																			//PB1 
#define KEY3 		GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_10) 																		//PB10
#define KEY4 	  GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_11)																		//PB11


/*���淽ʽ��ͨ��λ��������ʽ��ȡIO*/
/*
#define KEY1 		PBin(0)   //PB0
#define KEY2 		PBin(1)		//PB1 
#define KEY3 		PBin(10)		//PB10
#define KEY4 	PBin(11)		//PB11
*/

#define KEY1_PRES  1
#define KEY2_PRES	 2
#define KEY3_PRES	 3
#define KEY4_PRES  4

void KEY_Init(void);																																			
u8 KEY_Scan(u8);  																																	

#endif
