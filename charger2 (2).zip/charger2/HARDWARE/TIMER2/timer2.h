#ifndef __TIMER2_H
#define __TIMER2_H
#include "sys.h"
#include "usart.h"
void TIM2_Int_Init(u16 arr,u16 psc);
 
#endif



/* 	main()
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2); //设置NVIC中断分组2:2位抢占优先级，2位响应优先级
	TIM2_Int_Init(4999,7199);//10Khz的计数频率，计数到5000为500ms  
 */
