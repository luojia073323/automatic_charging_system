#ifndef __RELAY_H
#define __RELAY_H
#include "sys.h"

#define RELAY PBout(6)

void RELAY_Init(void);

//void relay_on(void);
//void relay_off(void);

#endif
