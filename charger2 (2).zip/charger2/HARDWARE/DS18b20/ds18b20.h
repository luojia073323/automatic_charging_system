
#ifndef __DS18B20_H
#define __DS18B20_H

#include "stm32f10x.h"

#define TDQ GPIO_Pin_9

#define OW_DIR_OUT() 	mode_output1()
#define OW_DIR_IN() 	mode_input1()
#define OW_OUT_LOW() 	(GPIO_ResetBits(GPIOB,TDQ))
#define OW_GET_IN()  	(GPIO_ReadInputDataBit(GPIOB,TDQ))

#define OW_SKIP_ROM 		0xCC
#define DS18B20_CONVERT 	0x44
#define DS18B20_READ 		0xBE


void ds18b20_init_x(void);
s16 ds18b20_read(void);
void DisplayDs18b20(void);

#endif

